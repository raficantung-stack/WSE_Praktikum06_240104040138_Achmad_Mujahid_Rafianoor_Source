// Jalankan: set NODE_EXTRA_CA_CERTS=%CD%\certs\localhost.crt && npm run testapi
const BASE = 'https://localhost:3443';
const API_KEY = process.env.API_KEY;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const READER_PASSWORD = process.env.READER_PASSWORD;
const checks = [];
let adminToken = '';
let readerToken = '';
let createdId = null;

async function send(method, path, body, headers = {}, rawBody = false) {
  const response = await fetch(BASE + path, {
    method,
    headers: {
      Accept: 'application/json',
      ...headers,
      ...(body === undefined ? {} : { 'Content-Type': rawBody ? 'text/plain' : 'application/json' })
    },
    ...(body === undefined ? {} : { body: rawBody ? body : JSON.stringify(body) }),
    signal: AbortSignal.timeout(5000)
  });
  const raw = await response.text();
  let payload = null;
  if (raw) { try { payload = JSON.parse(raw); } catch {} }
  return { status: response.status, payload, location: response.headers.get('location'), raw };
}

function record(label, got, expected) {
  const pass = String(got) === String(expected);
  checks.push(pass);
  console.log(`${pass ? 'PASS' : 'FAIL'} ${label}: ${got} (harapan ${expected})`);
}

async function login(username, password, apiKey = API_KEY) {
  return send('POST', '/auth/login', { username, password }, { 'x-api-key': apiKey });
}

async function main() {
  record('GET /health', (await send('GET', '/health')).status, 200);
  record('GET /docs/', (await send('GET', '/docs/')).status, 200);
  record('GET /openapi.json', (await send('GET', '/openapi.json')).status, 200);
  record('Katalog tanpa token', (await send('GET', '/api/buku')).status, 401);
  record('Login dengan API key salah', (await login('admin', ADMIN_PASSWORD, 'salah')).status, 401);
  record('Login dengan password salah', (await login('admin', 'password-salah-untuk-uji')).status, 401);

  const reader = await login('pembaca', READER_PASSWORD);
  record('Login pembaca', reader.status, 200);
  if (reader.status !== 200) throw new Error('Login pembaca gagal. Periksa .env.');
  readerToken = reader.payload.data.access_token;
  const readerAuth = { Authorization: `Bearer ${readerToken}` };
  record('Reader membaca katalog', (await send('GET', '/api/buku', undefined, readerAuth)).status, 200);
  record('Reader dilarang menambah buku', (await send('POST', '/api/buku', { judul: 'Tidak boleh', tersedia: true }, readerAuth)).status, 403);
  record('ID buku tidak valid', (await send('GET', '/api/buku/abc', undefined, readerAuth)).status, 400);
  record('Buku tidak ditemukan', (await send('GET', '/api/buku/999', undefined, readerAuth)).status, 404);

  const admin = await login('admin', ADMIN_PASSWORD);
  record('Login admin', admin.status, 200);
  if (admin.status !== 200) throw new Error('Login admin gagal. Periksa .env.');
  adminToken = admin.payload.data.access_token;
  const adminAuth = { Authorization: `Bearer ${adminToken}` };
  record('Content-Type bukan JSON', (await send('POST', '/api/buku', '{"judul":"Teks","tersedia":true}', adminAuth, true)).status, 415);
  record('Validasi tipe tersedia', (await send('POST', '/api/buku', { judul: 'Tidak valid', tersedia: 'true' }, adminAuth)).status, 400);
  record('Admin membuat buku', (await (async () => {
    const response = await send('POST', '/api/buku', { judul: 'Keamanan API Dasar', tersedia: true }, adminAuth);
    createdId = response.payload?.data?.id ?? null;
    record('Header Location setelah create', response.location, `/api/buku/${createdId}`);
    return response;
  })()).status, 201);
  if (createdId) {
    record('Admin memperbarui buku', (await send('PUT', `/api/buku/${createdId}`, { judul: 'Keamanan API Lanjut', tersedia: false }, adminAuth)).status, 200);
    record('Admin menghapus buku', (await send('DELETE', `/api/buku/${createdId}`, undefined, adminAuth)).status, 204);
  }
  record('Body melebihi 10kb', (await send('POST', '/api/buku', { judul: 'x'.repeat(11000), tersedia: true }, adminAuth)).status, 413);
  record('Token acak ditolak', (await send('GET', '/api/buku', undefined, { Authorization: `Bearer ${'a'.repeat(64)}` })).status, 401);
  record('Logout admin', (await send('POST', '/auth/logout', undefined, adminAuth)).status, 204);
  record('Token setelah logout dicabut', (await send('GET', '/api/buku', undefined, adminAuth)).status, 401);

  // Uji rate limit paling akhir agar tidak mengunci request login sebelumnya.
  for (let i = 1; i <= 5; i++) {
    const result = await login('admin', 'password-salah-untuk-rate-limit');
    record(`Percobaan login salah ke-${i}`, result.status, 401);
  }
  record('Pembatasan login setelah 5 kegagalan', (await login('admin', 'password-salah-untuk-rate-limit')).status, 429);

  const passed = checks.filter(Boolean).length;
  console.log(`HASIL AKHIR: ${passed}/${checks.length} pengujian lulus`);
  if (checks.some((x) => !x)) process.exitCode = 1;
}

main().catch((err) => {
  console.error('GAGAL:', err.message);
  process.exitCode = 1;
});
