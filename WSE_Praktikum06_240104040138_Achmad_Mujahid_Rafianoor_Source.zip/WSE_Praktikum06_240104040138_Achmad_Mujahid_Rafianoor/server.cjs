const fs = require('node:fs');
const https = require('node:https');
const app = require('./app.cjs');

const PORT = 3443;
const cert = './certs/localhost.crt';
const key = './certs/localhost.key';
if (!fs.existsSync(cert) || !fs.existsSync(key)) {
  console.error('Sertifikat TLS belum ada. Ikuti langkah pembuatan sertifikat pada README.');
  process.exit(1);
}
https.createServer({ cert: fs.readFileSync(cert), key: fs.readFileSync(key) }, app)
  .listen(PORT, '127.0.0.1', () => {
    console.log(`HTTPS lokal: https://localhost:${PORT}`);
    console.log('Dokumentasi: https://localhost:3443/docs');
    console.log('Listener dibatasi pada 127.0.0.1');
  });
