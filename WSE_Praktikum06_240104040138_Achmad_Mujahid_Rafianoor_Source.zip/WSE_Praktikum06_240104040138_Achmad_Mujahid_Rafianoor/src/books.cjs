const { HttpError, validateBook } = require('./errors.cjs');

let books = [
  { id: 1, judul: 'Dasar Pemrograman Kotlin', tersedia: true },
  { id: 2, judul: 'Dasar Web Service', tersedia: false }
];
let nextId = 3;

function detail(id) {
  const book = books.find((item) => item.id === id);
  if (!book) throw new HttpError(404, 'BOOK_NOT_FOUND', 'Buku tidak ditemukan.');
  return book;
}

module.exports = {
  list(q) {
    if (q !== undefined && (typeof q !== 'string' || q.length > 80)) {
      throw new HttpError(400, 'INVALID_QUERY', 'q harus satu teks maksimal 80 karakter.');
    }
    const keyword = (q || '').trim().toLowerCase();
    return books.filter((item) => item.judul.toLowerCase().includes(keyword));
  },
  detail,
  create(input) {
    const book = { id: nextId++, ...validateBook(input) };
    books.push(book);
    return book;
  },
  replace(id, input) {
    const data = validateBook(input);
    detail(id);
    const index = books.findIndex((item) => item.id === id);
    books[index] = { id, ...data };
    return books[index];
  },
  remove(id) {
    detail(id);
    books = books.filter((item) => item.id !== id);
  }
};
