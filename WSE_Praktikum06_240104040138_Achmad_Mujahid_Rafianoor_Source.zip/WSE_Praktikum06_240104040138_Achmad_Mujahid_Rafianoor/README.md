# Praktikum 06 - Keamanan Dasar Web Service

Proyek pembelajaran lokal untuk studi kasus Katalog Buku Perpustakaan Kampus. Fitur: API key saat login, password hashing scrypt, opaque Bearer token 15 menit, RBAC admin/reader, validasi input, pembatasan percobaan login, HTTPS localhost, OpenAPI 3.1.0, dan Swagger UI.

> Proyek ini hanya untuk latihan pada komputer sendiri. Tidak siap dipublikasikan langsung ke internet.

## Prasyarat

- Node.js 24.x dan npm (sesuai modul)
- OpenSSL
- Visual Studio Code / Command Prompt

## Instalasi

Paket dependensi akan diunduh dari registry npm dan `package-lock.json` dibuat otomatis pada instalasi pertama.

```cmd
npm install
copy .env.example .env
```

Edit `.env` dan isi `API_KEY`, `ADMIN_PASSWORD`, serta `READER_PASSWORD` dengan nilai acak/unik minimal 12 karakter. Jangan memakai password akun pribadi.

Buat sertifikat TLS self-signed untuk localhost dari akar proyek:

```cmd
openssl req -x509 -newkey rsa:2048 -sha256 -days 7 -nodes -keyout certs/localhost.key -out certs/localhost.crt -subj "/CN=localhost" -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
```

Generate OpenAPI dan jalankan server:

```cmd
npm run docs
npm start
```

Akses `https://localhost:3443/docs` setelah sertifikat lokal dipercaya melalui mekanisme yang disetujui. Jangan menonaktifkan verifikasi TLS secara global.

Di terminal kedua pada direktori proyek:

```cmd
set NODE_EXTRA_CA_CERTS=%CD%\certs\localhost.crt
npm run testapi
```

## Akun kelas

- Username `admin`; password dibaca dari `.env`.
- Username `pembaca`; password dibaca dari `.env`.
- API key juga dibaca dari `.env`.

Token berlaku 15 menit. Data katalog dan sesi disimpan dalam memori; seluruhnya hilang saat server dihentikan/restart.

## Endpoint utama

| Metode | Endpoint | Hak akses | Berhasil |
|---|---|---|---|
| GET | `/health` | Publik | 200 |
| POST | `/auth/login` | API key + kredensial | 200 |
| POST | `/auth/logout` | Bearer token | 204 |
| GET | `/api/buku` | reader/admin | 200 |
| GET | `/api/buku/:id` | reader/admin | 200 |
| POST | `/api/buku` | admin | 201 |
| PUT | `/api/buku/:id` | admin | 200 |
| DELETE | `/api/buku/:id` | admin | 204 |

## Batas desain

Belum ada database, audit trail formal, secret manager, persistent sessions, rotasi kunci terjadwal, rate limiting terdistribusi, atau PKI publik. Jangan commit `.env`, sertifikat, private key, token, maupun `node_modules`.
